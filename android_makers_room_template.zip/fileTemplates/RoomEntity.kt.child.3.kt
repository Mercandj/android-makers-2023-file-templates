#parse("RoomEntityState.kt")
${REPOSITORY_IMPL_PACKAGE}
${REPOSITORY_IMPL_IMPORTS}

class ${REPOSITORY_IMPL_CLASS}(
    private val ${DAO_ARG} : ${DAO_CLASS}
): ${REPOSITORY_CLASS} {

    override suspend fun add${MODEL_CLASS}(${MODEL_ARG}: ${MODEL_CLASS}){
        ${DAO_ARG}.add${MODEL_CLASS}(${MODEL_ARG}.toDTO())
    }

    override fun get${MODEL_CLASS}s(): Flow<List<${MODEL_CLASS}>>{
        return ${DAO_ARG}.get${MODEL_CLASS}s().map { ${MODEL_ARG}List ->
            ${MODEL_ARG}List.map { ${DTO_ARG} ->
                ${DTO_ARG}.toModel()
            }
        }
    }

    override suspend fun get${MODEL_CLASS}ForId(id: String): ${MODEL_CLASS}{
        return ${DAO_ARG}.get${MODEL_CLASS}ForId(id).toModel()
    }
    
    override suspend fun update${MODEL_CLASS}(${MODEL_ARG}: ${MODEL_CLASS}){
        ${DAO_ARG}.update${MODEL_CLASS}(${MODEL_ARG}.toDTO())
    }

    override suspend fun delete${MODEL_CLASS}(${MODEL_ARG}: ${MODEL_CLASS}){
        ${DAO_ARG}.delete${MODEL_CLASS}(${MODEL_ARG}.toDTO())
    }
}
