#parse("RoomEntityState.kt")
${REPOSITORY_PACKAGE}
${REPOSITORY_IMPORTS}

interface ${REPOSITORY_CLASS} {

    suspend fun add${MODEL_CLASS}(${MODEL_ARG}: ${MODEL_CLASS})

    fun get${MODEL_CLASS}s(): Flow<List<${MODEL_CLASS}>>

    suspend fun get${MODEL_CLASS}ForId(id: String): ${MODEL_CLASS}
    
    suspend fun update${MODEL_CLASS}(${MODEL_ARG}: ${MODEL_CLASS})

    suspend fun delete${MODEL_CLASS}(${MODEL_ARG}: ${MODEL_CLASS})
}
