#parse("RoomDatabaseState.kt")
${DATABASE_PACKAGE}
${DATABASE_IMPORTS}

@Database(
    entities = [${ENTITIES}],
    version = 1,
    exportSchema = false
)
abstract class ${DATABASE_CLASS} : RoomDatabase() {
    
    ${DAO_DECLARATION}

    companion object {

        @Volatile
        private var instance: ${DATABASE_CLASS}? = null
        
        fun get${DATABASE_CLASS}(context: Context): ${DATABASE_CLASS}  =
            instance ?: synchronized(this) {
                instance ?: buildDatabase(context)
                    .also { instance = it }
            }
            
        private fun buildDatabase(context: Context) =
            Room.databaseBuilder(context, ${DATABASE_CLASS}${CLASS_REFERENCE}.java, "${DATABASE_VALUE}" )
                .fallbackToDestructiveMigration()
                .build()
    }
}
