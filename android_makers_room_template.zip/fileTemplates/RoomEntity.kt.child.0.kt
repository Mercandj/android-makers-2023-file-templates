#parse("RoomEntityState.kt")
${DTO_PACKAGE}
${DTO_IMPORTS}

@Entity(tableName = ${TABLE_NAME})
data class ${DTO_CLASS}(
    @PrimaryKey(autoGenerate = false)
    ${ARGUMENTS}
    ){
    fun toModel(): ${MODEL_CLASS}{
        return ${MODEL_CLASS}(
            ${ARGUMENT_ASSIGNMENT}
        )
    }
}