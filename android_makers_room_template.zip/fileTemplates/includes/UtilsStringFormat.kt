## ----------------- NameToCamelCase
#set($NameToCamelCase = ${StringUtils.removeAndHump(${NAME}, "_")})
## ----------------- NameToUpperCase
#set($NameToUpperCase = $NAME.toUpperCase())
## ----------------- NameToLowerCamelCase
#set($firstLetter = $NameToCamelCase.substring(0,1).toLowerCase())
#set($theRest = $NameToCamelCase.substring(1))
#set($NameToLowerCamelCase = ${firstLetter} + ${theRest})
## ----------------- NameToSnakeCase
#set( $regex = "([a-z])([A-Z]+)")
#set( $replacement = "$1_$2")
#set( $NameToSnakeCase = $NAME.replaceAll($regex, $replacement).toLowerCase())
