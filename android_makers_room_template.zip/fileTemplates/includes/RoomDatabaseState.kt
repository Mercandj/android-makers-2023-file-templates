#parse("UtilsStringFormat.kt")## String Format Import
#set($entitiesList = $ENTITIES_LIST)## Value to Prompt
## ------------------------------------------- STRING FORMAT
## ------------------------------------------- Entities to array
#set($entitiesArray = ${StringUtils.split($entitiesList, ",")})
## ------------------------------------------- Format entities 
#set($class = "::class")
#set($foreach = 0)
#foreach ($entity in $entitiesArray)
#if ($foreach.count == 1)
#set($entities = "${StringUtils.capitalizeFirstLetter($entity)}DTO$class")
#else
#set($entities = "$entities,${StringUtils.capitalizeFirstLetter($entity)}DTO$class")
#end
#end
## ------------------------------------------- Format Dao
#set( $entity = "" )
#foreach($entity in $entitiesArray )
#set($modifiedName = ${StringUtils.removeAndHump(${entity}, "_")})
#set($firstLetter = $modifiedName.substring(0,1).toLowerCase())
#set($theRest = $modifiedName.substring(1))
#set($snakeCaseToLowerCamelCase = ${firstLetter} + ${theRest})
#if ($foreach.count == 1)
#set($doaDeclaration = "abstract fun ${snakeCaseToLowerCamelCase}Dao(): ${entity}Dao")
#else
#set($doaDeclaration = "$doaDeclaration
abstract fun ${snakeCaseToLowerCamelCase}Dao(): ${entity}Dao")
#end
#end
## ------------------------------------------- Format Test Declarations
#set( $testDeclaration = "private lateinit var database: ${NameToCamelCase}RoomDatabase" )
#set( $entity = "" )
#set( $testDaoAssignment = "" )
#foreach($entity in $entitiesArray )
#set($modifiedName = ${StringUtils.removeAndHump(${entity}, "_")})
#set($firstLetter = $modifiedName.substring(0,1).toLowerCase())
#set($theRest = $modifiedName.substring(1))
#set($snakeCaseToLowerCamelCase = ${firstLetter} + ${theRest})
#set($testDaoAssignment = "$testDaoAssignment
${snakeCaseToLowerCamelCase}Dao = database.${snakeCaseToLowerCamelCase}Dao()")
#set($testDeclaration = "$testDeclaration
private lateinit var ${snakeCaseToLowerCamelCase}Dao : ${entity}Dao")
#end
## ------------------------------------------- Format Imports
#set($databaseImports = "import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase") ## ---------------------
#set($databaseTestImports = "import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.SmallTest
import ${PACKAGE_NAME}.data.${NAME}.${NameToCamelCase}RoomDatabase
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith")
#foreach($entity in $entitiesArray )
#set( $regex = "([a-z])([A-Z]+)")
#set( $replacement = "$1_$2")
#set( $entityToSnakeCase = $entity.replaceAll($regex, $replacement).toLowerCase())
#set($daoImport = "import ${PACKAGE_NAME}.data.${entityToSnakeCase}_repository.${entity}Dao")
#set($dtoImport = "import ${PACKAGE_NAME}.domain.${entityToSnakeCase}.${entity}DTO")
#set($databaseImports = "${databaseImports}
${daoImport}
${dtoImport}")
#set($databaseTestImports = "${databaseTestImports}
${daoImport}
${dtoImport}")
#end ## ---------------------
## ------------------------------------------- Format Package
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")
#set($databasePackage = "package ${PACKAGE_NAME}.data.${NAME}
" )
#set($databaseTestPackage = "package ${PACKAGE_NAME}.${NAME}_test
" )
#end
## ------------------------------------- EXPOSED VALUES
#set($CLASS_REFERENCE = $class)
#set($DATABASE_IMPORTS = $databaseImports)
#set($DATABASE_PACKAGE = $databasePackage)
#set($DATABASE_TEST_IMPORTS = $databaseTestImports)
#set($DATABASE_TEST_PACKAGE = $databaseTestPackage)
## ---------- CAMEL CASE NAME -------------
#set($DATABASE_CLASS = "${NameToCamelCase}RoomDatabase")
#set($DATABASE_TEST_CLASS = "${NameToCamelCase}DatabaseTest")
## ------------------- DB VALUE -------------
#set($DATABASE_VALUE = "${NameToSnakeCase}_db")
## ------------------- ENTITIES -------------
#set($ENTITIES_ARRAY = $entitiesArray)
#set($ENTITIES = $entities)
## ------------------- DAO -------------
#set($DAO_DECLARATION = $doaDeclaration)
## ------------------ TEST -------------
#set($TEST_DECLARATION = $testDeclaration)
#set($TEST_DAO_ASSIGNMENT = $testDaoAssignment)

