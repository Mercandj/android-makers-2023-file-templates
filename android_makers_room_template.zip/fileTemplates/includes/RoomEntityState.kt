#parse("UtilsStringFormat.kt")## String Format Import
#set($argumentListDTO = $ARGUMENT_LIST)## Value to Prompt
## ------------------------------------------- STRING FORMAT
## ------------------------------------------- Argument To Array
#set($argumentArray = ${StringUtils.split($argumentListDTO, ",")})
## ------------------------------------------- Format Table name
#set($tableName = "${NameToUpperCase}_TABLE")
## ------------------------------------------- Format argument and argument assignment
#set($argumentAssignment ="")
#set($arguments = "")
#set($argumentType = "")
#set($foreach = "")
#foreach($argumentType in $argumentArray)
#set($argumentNameArray = ${StringUtils.split($argumentType, ":")})
#set($arguments = "${arguments}val ${argumentType}")
#set($argumentAssignment = "${argumentAssignment}$argumentNameArray.get(0) = this.$argumentNameArray.get(0)")
#if($foreach.hasNext())
#set($argumentAssignment = "${argumentAssignment},
")
#set($arguments = "${arguments},
") 
#end
#end
## ------------------------------------------- Format Imports
#set($daoImports = "import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow
import ${PACKAGE_NAME}.domain.${NAME}.${NameToCamelCase}DTO") ## ---------------------
#set($dtoImports = "import androidx.room.Entity
import androidx.room.PrimaryKey
import ${PACKAGE_NAME}.data.${NAME}_repository.${NameToCamelCase}Dao.Companion.${tableName}") ## ---------------------
#set($modelImport = "import ${PACKAGE_NAME}.domain.${NAME}.${NameToCamelCase}")
#set($repositoryImports = "import kotlinx.coroutines.flow.Flow
${modelImport}") ## ---------------------
#set($repositoryImplImports = "import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
${modelImport}") ## ---------------------
## ------------------------------------------- Format Package
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")
#set($repositoryPath = "package ${PACKAGE_NAME}.data.${NAME}_repository")
#set($domainPath = "package ${PACKAGE_NAME}.domain.${NAME}")
#set($daoPackage = "${repositoryPath}
" )
#set($dtoPackage = "${domainPath}
" )
#set($modelPackage = "${domainPath}
" )
#set($repositoryPackage = "${repositoryPath}
" )
#set($repositoryImplPackage = "${repositoryPath}
" )
#end
## ------------------------------------------- EXPOSED VALUES
## ------------------------------------------- TABLE NAME
#set($TABLE_NAME = $tableName)
## ------------------------------------------- PACKAGE
#set($DAO_PACKAGE = $daoPackage)
#set($DTO_PACKAGE = $dtoPackage)
#set($MODEL_PACKAGE = $modelPackage)
#set($REPOSITORY_PACKAGE = $repositoryPackage)
#set($REPOSITORY_IMPL_PACKAGE = $repositoryImplPackage)
## ------------ IMPORTS ---------------------
#set($DAO_IMPORTS = $daoImports)
#set($REPOSITORY_IMPORTS = $repositoryImports)
#set($REPOSITORY_IMPL_IMPORTS = $repositoryImplImports)
#set($DTO_IMPORTS = $dtoImports)
## ---------- CAMEL CASE NAME -----------------
#set($MODEL_CLASS = $NameToCamelCase)
#set($DAO_CLASS = "${NameToCamelCase}Dao")
#set($DTO_CLASS = "${NameToCamelCase}DTO")
#set($REPOSITORY_CLASS = "${NameToCamelCase}Repository")
#set($REPOSITORY_IMPL_CLASS = "${NameToCamelCase}RepositoryImpl")
## ---------- LOWER CAMEL CASE NAME -------------
#set($DTO_ARG = "${NameToLowerCamelCase}DTO")
#set($DAO_ARG = "${NameToLowerCamelCase}Dao")
#set($MODEL_ARG = "${NameToLowerCamelCase}")
## ---------- ARGUMENT ASSIGNMENT -------------
#set($ARGUMENT_ASSIGNMENT = $argumentAssignment)
#set($ARGUMENTS = $arguments)