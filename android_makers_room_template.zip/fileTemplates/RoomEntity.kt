#parse("RoomEntityState.kt")
${DAO_PACKAGE}
${DAO_IMPORTS}

@Dao
interface ${DAO_CLASS} {

    @Insert
    suspend fun add${MODEL_CLASS}(${DTO_ARG}: ${DTO_CLASS})

    @Query("SELECT*FROM ${DS}${TABLE_NAME}")
    fun get${MODEL_CLASS}s(): Flow<List<${DTO_CLASS}>>

    @Query("SELECT*FROM ${DS}${TABLE_NAME} WHERE ${DS}${TABLE_NAME}.id = :id ")
    suspend fun get${MODEL_CLASS}ForId(id: String): ${DTO_CLASS}

    @Update
    suspend fun update${MODEL_CLASS}(${DTO_ARG}: ${DTO_CLASS})

    @Delete
    suspend fun delete${MODEL_CLASS}(${DTO_ARG}: ${DTO_CLASS})

    companion object{
        const val ${TABLE_NAME} = "${NAME}_table"
    } 
}
