#parse("RoomDatabaseState.kt")
${DATABASE_TEST_PACKAGE}
${DATABASE_TEST_IMPORTS}

@RunWith(AndroidJUnit4::class)
@SmallTest
class ${DATABASE_TEST_CLASS} {

    ${TEST_DECLARATION}

    @Before
    fun setupDatabase() {
        database = Room.inMemoryDatabaseBuilder(
            ApplicationProvider.getApplicationContext(),
            ${DATABASE_CLASS}::class.java
        ).allowMainThreadQueries().build()
        ${TEST_DAO_ASSIGNMENT}
    }

    @After
    fun closeDatabase() {
        database.close()
    }
    
    @Test
    fun implementNeededTest(){
        TODO("Please, implement test for the Database.")
    }
    
}