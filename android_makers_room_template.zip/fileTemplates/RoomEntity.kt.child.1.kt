#parse("RoomEntityState.kt")
${MODEL_PACKAGE}
data class ${MODEL_CLASS}(
    ${ARGUMENTS}
    ){
    fun toDTO(): ${DTO_CLASS}{
        return ${DTO_CLASS}(
            ${ARGUMENT_ASSIGNMENT}
        )
    }
}